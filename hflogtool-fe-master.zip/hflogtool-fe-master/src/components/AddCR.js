import React from 'react';
import {Card, Form, Button, Col} from 'react-bootstrap';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import { faSave, faPlusSquare, faUndo} from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';

class AddCr extends React.Component {
      constructor(props){
     super(props);
     this.state = this.initialState;
      this.crChange = this.crChange.bind(this);
      this.submitCr = this.submitCr.bind(this);
      this.updateCr =  this.updateCr.bind(this);
   }

   initialState = {
     id:'', title:'', productName:'', releaseTag:'',
          owner:'', type:'', reportingRelease:'', rolledUpToRelease:'',
           rolledDownFromRelease:'', gerritIds:'', comments:''
   }

  componentDidMount() {
    const crId = this.props.match.params.id;
    if(crId){
     this.findCrById(crId);

    }
  }
  findCrById=(crId)=>{
            axios.get("/CR/"+crId).then(response=>{
              if(response.data!=null){
              this.setState(
              {
                  gerritIds: [response.data.gerritIds],
                  comments: response.data.comments,
                  id: response.data.id,
                  owner: response.data.owner,
                  productName: response.data.productName,
                  releaseTag: response.data.releaseTag,
                  reportingRelease: response.data.reportingRelease,
                  rolledUpToRelease: response.data.rolledUpToRelease,
                  rolledDownFromRelease: response.data.rolledDownFromRelease,
                  title: response.data.title,
                  type: response.data.type
              });
            }
       });
  }


   resetCr = () => {
     this.setState(() => this.initialState);
   }

   submitCr(event){
      event.preventDefault();
      const cr = {
          gerritIds: [this.state.gerritIds],
          comments: this.state.comments,
          id: this.state.id,
          owner: this.state.owner,
          productName: this.state.productName,
          releaseTag: this.state.releaseTag,
          reportingRelease: this.state.reportingRelease,
          rolledUpToRelease: this.state.rolledUpToRelease,
          rolledDownFromRelease: this.state.rolledDownFromRelease,
          title: this.state.title,
          type: this.state.type
      };
     axios.post('/CR', cr)
         .then(response => {
            if(response.data != null){
               this.setState(this.initialState);
               alert("CR saved Successfully");
            }
         });

   }

   updateCr(event){
     event.preventDefault();
     //  const crId = this.state.id;
     //const crId = this.cr.id;
     const crId = this.props.match.params.id;
           const cr = {
               gerritIds: [this.state.gerritIds],
               comments: this.state.comments,
               id: this.state.id,
               owner: this.state.owner,
               productName: this.state.productName,
               releaseTag: this.state.releaseTag,
               reportingRelease: this.state.reportingRelease,
               rolledUpToRelease: this.state.rolledUpToRelease,
               rolledDownFromRelease: this.state.rolledDownFromRelease,
               title: this.state.title,
               type: this.state.type
           };
          axios.put("/CR/"+crId, cr)
              .then(response => {
                 if(response.data != null){
                    this.setState(this.initialState);
                    alert("CR Updated Successfully");
                 }
              });

   }

   crChange(event)
   {
      this.setState({[event.target.name]:event.target.value});
   }


    render(){
     const {id,title,productName,releaseTag,owner,type,reportingRelease,rolledUpToRelease,rolledDownFromRelease,gerritIds,comments} = this.state;

       return (
       <Card className="">
          <Card.Header><FontAwesomeIcon icon={faPlusSquare} />Add CR</Card.Header>
          <Form onReset={this.resetCr} onSubmit={this.submitCr} id="crFormId">
             <Card.Body>
              <Form.Row>
                 <Form.Group as={Col} controlId="formGridId">
                  <Form.Label>Id</Form.Label>
                   <Form.Control required autoComplete= "off"
                   type="test"
                   name= "id"
                   value={id}
                   onChange={this.crChange}
                   className={"bg-white text-dark"}
                   placeholder="Enter Id" />
                 </Form.Group>
                 <Form.Group as={Col} controlId="formGridTitle">
                    <Form.Label>Title</Form.Label>
                    <Form.Control required autoComplete= "off" type="test" name= "title"
                    value={title}
                    onChange={this.crChange}
                    className={"bg-white text-dark"} placeholder="Enter Title" />
                 </Form.Group>
              </Form.Row>
               <Form.Row>
                  <Form.Group as={Col} controlId="formGridProductName">
                    <Form.Label>Product Name</Form.Label>
                     <Form.Control required autoComplete= "off" type="test" name= "productName"
                     value={productName}
                      onChange={this.crChange}
                      className={"bg-white text-dark"} placeholder="Enter product name" />
                   </Form.Group>
                   <Form.Group as={Col} controlId="formGridReleaseTag">
                      <Form.Label>Release Tag</Form.Label>
                      <Form.Control required autoComplete= "off" type="test" name= "releaseTag"
                      value={releaseTag}
                      onChange={this.crChange}
                      className={"bg-white text-dark"} placeholder="Enter release tag" />
                   </Form.Group>
                </Form.Row>
                <Form.Row>
                    <Form.Group as={Col} controlId="formGridOwner">
                     <Form.Label>Owner</Form.Label>
                      <Form.Control required autoComplete= "off" type="test" name= "owner"
                      value={owner}
                      onChange={this.crChange}
                       className={"bg-white text-dark"} placeholder="Enter owner name" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridType">
                       <Form.Label>Type</Form.Label>
                       <Form.Control required autoComplete= "off" type="test" name= "type"
                       value={type}
                       onChange={this.crChange}
                       className={"bg-white text-dark"} placeholder="Enter type" />

                    </Form.Group>
                 </Form.Row>
                 <Form.Row>
                     <Form.Group as={Col} controlId="formGridReportingRelease">
                      <Form.Label>Reporting Release</Form.Label>
                       <Form.Control required autoComplete= "off" type="test" name= "reportingRelease"
                       value={reportingRelease}
                       onChange={this.crChange}
                        className={"bg-white text-dark"} placeholder="Enter reporting release" />
                     </Form.Group>
                     <Form.Group as={Col} controlId="formGridRolledUpToRelease">
                        <Form.Label>RolledUpTo Release</Form.Label>
                        <Form.Control autoComplete= "off" type="test" name= "rolledUpToRelease"
                        value={rolledUpToRelease}
                        onChange={this.crChange}
                         className={"bg-white text-dark"} placeholder="Enter rolledup to release" />
                     </Form.Group>
                  </Form.Row>
                 <Form.Row>
                      <Form.Group as={Col} controlId="formGridRolledDownFromRelease">
                       <Form.Label>RolledDownFrom Release</Form.Label>
                        <Form.Control autoComplete= "off" type="test" name= "rolledDownFromRelease"
                        value={rolledDownFromRelease}
                        onChange={this.crChange}
                        className={"bg-white text-dark"} placeholder="Enter rolleddown from release" />
                      </Form.Group>
                      <Form.Group as={Col} controlId="formGridGerritId">
                         <Form.Label>Gerrit URL</Form.Label>
                         <Form.Control required autoComplete= "off" type="test" name= "gerritIds"
                         value={gerritIds}
                          onChange={this.crChange}
                          className={"bg-white text-dark"} placeholder="Enter gerrit URL" />
                      </Form.Group>
                 </Form.Row>
                  <Form.Row>
                      <Form.Group as={Col} controlId="formGridComment">
                       <Form.Label>Comment</Form.Label>
                        <Form.Control autoComplete= "off" type="test" name= "comments"
                        value={comments}
                         onChange={this.crChange}
                         className={"bg-white text-dark"} placeholder="Write your comments" />
                      </Form.Group>

                  </Form.Row>
              </Card.Body>
              <Card.Footer style ={{"textAlign":"right"}}>
                  <Button size="sm" variant="success" type="submit">
                  <FontAwesomeIcon icon={faSave} />Submit
                  </Button>{' '}
                  <Button size="sm" variant="info" type="reset">
                    <FontAwesomeIcon icon={faUndo} />
                    Reset</Button>
              </Card.Footer>
           </Form>
       </Card>
       );
    }

}

export default AddCr;
