import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom';
import {Container, Row, Col} from 'react-bootstrap';
import AddCR from "./components/AddCR";
import CRList from "./components/CRList";
import UpdateCR from "./components/UpdateCR";
import Navigation from "./components/Navigation";
import {Button} from "reactstrap";
import {ToastContainer,toast} from "react-toastify";
import Home from "./components/Home";
function App() {
const btnhandle=()=>{
toast("This is first message");
};

 return (
    <Router>
  <Navigation />
  <Switch>
  <Route path="/" exact component={Home}/>
  <Route path="/add" exact component={AddCR}/>
   <Route path="/list" exact component={CRList}/>
    <Route path="/edit/:id" exact component={UpdateCR}/>
  </Switch>
    {/*<Course /> */}
    </Router>
  );
}

export default App;
