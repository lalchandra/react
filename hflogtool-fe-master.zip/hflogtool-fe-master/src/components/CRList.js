import React, {Component , Fragment} from 'react';
import axios from 'axios';
import {Card,Table,Button,ButtonGroup} from 'react-bootstrap';
import {Link} from 'react-router-dom';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import { faSave, faPlusSquare, faUndo} from '@fortawesome/free-solid-svg-icons';
class CRList extends Component{
constructor(props){
super(props)
this.state={cr : [] };
}
componentDidMount() {
axios.get('/CR')
        .then(response => response.data)
        .then((data) =>{
          this.setState({cr: data});
        });
  }
deleteCR = (crID)=>{
if(window.confirm('Are you sure want to delete this entry:'+crID))
{
axios.delete("/CR/"+crID).then(response=>{
if(response.data!=null)
{
alert("CR is deleted successfully");
this.setState(
{cr: this.state.cr.filter(crid=>crid.id!=crID)}
);

}
},(error)=>{alert("Oops! Something wrong");}
);
}
};
gerr=(gerritList)=>{
const gerritLinks=gerritList.map(
(gerrit)=><a href={gerrit}><p>{gerrit}</p></a>
);
return gerritLinks;
}
render(){
return(
<Card className={"border"}>
<Card.Header><FontAwesomeIcon icon={faPlusSquare} />CR List</Card.Header>
<Card.Body>
<Table bordered hover striped style={{marginLeft: '-2.5%'}}>
   <thead>
                      <tr>
                         <th>Release Tag</th>
                         <th>Owner</th>
                         <th>Type</th>

                         <th>Id</th>
                         <th>Title</th>
                         <th>Product Name</th>
                         <th>Reporting Release</th>
                         <th>RolledUpTo Release</th>
                         <th>RolledDownFrom Release</th>
                         <th>Comments</th>

                         <th>Gerrit Ids</th>
                         <th>U/D</th>
                            </tr>
                     </thead><tbody>
                    {
                      this.state.cr.length === 0 ?
                      <tr align="center">
                        <td colSpan="11">No CR are available</td>
                      </tr> :
                      this.state.cr.map((cr) =>(
                         <tr widht="50%" key={cr.id}>
                          <td>{cr.id}</td>
                          <td>{cr.title}</td>
                          <td>{cr.productName}</td>
                          <td>{cr.releaseTag}</td>
                          <td>{cr.owner}</td>
                          <td>{cr.type}</td>
                          <td>{cr.reportingRelease}</td>
                          <td>{cr.rolledUpToRelease}</td>
                          <td>{cr.rolledDownFromRelease}</td>
                          <td>{cr.comments}</td>
                          <td>{this.gerr(cr.gerritIds)}</td>


                          <td>
                          <ButtonGroup><div>
                           <Link to={"edit/"+cr.id} className="btn btn-sm btn-outline-primary">U</Link><br />
                       <Button size="sm" variant ="outline-danger" onClick={this.deleteCR.bind(this,cr.id)}>D</Button>
                        </div>
                        </ButtonGroup>

                          </td>
                       </tr>

                      ))
                     }
                    </tbody>
</Table>

</Card.Body>
</Card>
);
}}
export default CRList;
