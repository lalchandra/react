import React, {Component} from 'react';
import { Jumbotron,Container,Button } from "reactstrap";

class Home extends Component{
render(){
return(<div>
<Jumbotron className="text-center">
<h1>Welcome to Hotfix Log Tool</h1>
<p>This is the tool to find the statistics regarding fixes</p>
</Jumbotron>
</div>
)
}}
export default Home;

