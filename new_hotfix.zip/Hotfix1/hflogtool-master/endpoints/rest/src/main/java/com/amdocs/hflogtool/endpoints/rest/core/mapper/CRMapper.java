package com.amdocs.hflogtool.endpoints.rest.core.mapper;

import com.amdocs.hflogtool.model.CR;
import com.amdocs.hflogtool.model.CREntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
@Mapper(componentModel = "spring")
public interface CRMapper {

    CRMapper INSTANCE = Mappers.getMapper(CRMapper.class);

    @Mapping(source="gerritIds",target="gerritId",qualifiedByName = "listToString")
    CREntity mapCRToCREntity(CR cr);
    @Mapping(source="gerritId",target="gerritIds",qualifiedByName = "StringToList")
    CR mapCREntityToCR(CREntity crEntity);
    @Named("listToString")
    public static String listToString(List<String> list)
    {
        String str=String.join(",", list);
        return str;
    }
    @Named("StringToList")
    public static List<String> StringToList(String str)
    {
        List<String> list = Stream.of(str.split(",", -1))
                .collect(Collectors.toList());
        return list;
    }
}
